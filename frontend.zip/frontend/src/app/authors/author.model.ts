export class AuthorModel{
    constructor(
        public name: String,
        public books: String,
        public country: String,
        public img: String){}
}