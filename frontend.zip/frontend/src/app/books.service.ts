import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BooksService {

  constructor(private http:HttpClient) { }
  getBooks(){
    return this.http.get('http://localhost:5000/books');
  }

  singleBook(id){
    return this.http.get('http://localhost:5000/books/single', {
      params:{ i: id }
    });
  }

  deleteBook(id:any){
    return this.http.delete('http://localhost:5000/books/remove/'+id)
    .subscribe(data=>{console.log(data)})
  }

  newBook(item){
    return this.http.post('http://localhost:5000/addbook', {'book':item})
    .subscribe(data =>{console.log(data)})
  }

  updateBook(id:any,item){
    return this.http.post('http://localhost:5000/books/update/'+id,{'book':item})
    .subscribe(data=>{console.log(data)})
  }
}
