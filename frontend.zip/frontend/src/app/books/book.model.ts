export class BookModel{
    constructor(
        public BookName: String,
        public Author: String,
        public Genre: String,
        public Cover: String){}
}